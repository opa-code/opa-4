unit opaeditor;

{$MODE Delphi}

interface

uses
  LCLIntf, LCLType, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls,
  globlib, editorlib, varlib, comauxlib,  oelecreate, oeleedit, osegedit;

type

  { TFormEdit }

  TFormEdit = class(TForm)
    ButExit: TButton;
    ChkGloRI: TCheckBox;
    chkAllAper: TCheckBox;
    Edrref: TEdit;
    lab_rref: TLabel;
    ListBoxE: TListBox;
    ListBoxS: TListBox;
    LabelElem: TLabel;
    LabelSegm: TLabel;
    Label1: TLabel;
    LabGloE: TLabel;
    LabGloEU: TLabel;
    EditGloE: TEdit;
    ButDipInv: TButton;
    MemCom: TMemo;
    LabCom: TLabel;
    ButAllAper: TButton;
    EditAx: TEdit;
    EditAy: TEdit;
    ButExpUnd: TButton;
    procedure ButExitClick(Sender: TObject);
    procedure EdrrefKeyPress(Sender: TObject; var Key: char);
    procedure ListBoxEClick(Sender: TObject);
    procedure ListBoxSClick(Sender: TObject);
    procedure EditGloEKeyPress(Sender: TObject; var Key: Char);
    procedure ButDipInvClick(Sender: TObject);
    procedure EditAxKeyPress(Sender: TObject; var Key: Char);
    procedure EditAyKeyPress(Sender: TObject; var Key: Char);
    procedure ButAllAperClick(Sender: TObject);
    procedure ButExpUndClick(Sender: TObject);
  private
    cshandle: TComboBox;
    EleVarNames, SegmNames: TStrings;
    radref: real;
    procedure FillLists;
  public
    procedure Init (handle: TComboBox);
  end;

var
  FormEdit: TFormEdit;

implementation

{$R *.lfm}

{------------------------------------------------------------}

procedure TFormEdit.ButExitClick(Sender: TObject);
var i: integer;
begin
// create new LineBuffer (Latwrite does it) and TextBuffer to serve as
// backup for opatexteditor

  with glob do begin
    rot_inv:=ChkGloRI.Checked;
    text:=MemCom.text;
    for i:=0 to Length(text)-1 do begin
      if text[i]='{' then text[i]:=' ';
      if text[i]='}' then text[i]:=' ';
    end;
  end;
  if cshandle <> nil then begin
    FillComboSeg(cshandle);
//    cshandle.itemindex:=glob.nsegm-1;
  end;
  if FormEdit<>nil then begin
    Release;
    FormEdit:=nil;
  end;
end;


{------------------------------------------------------------}

procedure TFormEdit.FillLists;
var i:integer;
begin
  with ListBoxE do begin
    Clear;
    EleVarNames:=TStringList.Create;
    EleVarNames.Add('-- new entry --');
    for i:=1 to Glob.NElem do begin
      EleVarNames.Add(ElemToStr(i) );
    end;
    for i:=0 to High(Variable) do begin
      EleVarNames.Add(VariableToStr(i));
    end;
    Items:=EleVarNames;
  end;
  with ListBoxS do begin
    Clear;
    SegmNames:=TStringList.Create;
    SegmNames.Add('-- new entry --');
    for i:=1 to Glob.NSegm do begin
      SegmNames.Add(SegmToStr(i) );
    end;
    Items:=SegmNames;
  end;
end;

{------------------------------------------------------------}

procedure TFormEdit.Init (handle: TComboBox);
begin
  cshandle:=handle;
  {fill elements and segments into listboxes}
  FillLists;
  EditGloE.Text:=FtoS(Glob.Energy,8,4);
  ChkGloRI.Checked:=Glob.rot_inv;
  EditAx.Text:=FtoS(Glob.Ax,5,1);
  EditAy.Text:=FtoS(Glob.Ay,5,1);
  radref:=FDefGet('envel/rref');
  Edrref.Text:=Ftos(radref,5,1);
  MemCom.Text:=glob.text;
end;


{------------------------------------------------------------}

procedure TFormEdit.ListBoxEClick(Sender: TObject);
var
  iev: integer;
begin
{get index of selected element: if NEW (0) then launch elem create form,
if other, launch elem set form. pass handle to element list box for
updating}

  iev:= ListBoxE.ItemIndex;
  if iev=0 then begin
    if EditElemCreate= nil then EditElemCreate:=TEditElemCreate.Create(Application);
    EditElemCreate.Init (ListBoxE, EditSegSet);
    EditElemCreate.Show;
  end else begin
    if EditElemSet=nil then EditElemSet:=TEditElemSet.Create(Application);
    if iev <= Glob.Nelem then EditElemSet.InitE (ListBoxE) else EditElemSet.InitEVar (ListBoxE);
    EditElemSet.Show;
  end;
end;

{------------------------------------------------------------}

procedure TFormEdit.ListBoxSClick(Sender: TObject);
//var isegm: integer;
begin
//  isegm:=ListBoxS.ItemIndex;
  if EditSegSet=nil then EditSegSet:=TEditSegSet.Create(Application);
  EditSegSet.Init(ListBoxS);
  EditSegSet.Show;
end;

{------------------------------------------------------------}

procedure TFormEdit.EditGloEKeyPress(Sender: TObject; var Key: Char);
begin
  TEKeyVal(EditGloE, Key, glob.energy, 8, 4);
end;
{------------------------------------------------------------}

procedure TFormEdit.ButDipInvClick(Sender: TObject);
var j: integer;
begin
  for j:=1 to glob.nelem do with elem[j] do begin
    if cod=cbend then begin
      phi:=-phi; tin:=-tin; tex:=-tex;
    end;
    if elem[j].cod=ccomb then begin
      cphi:=-cphi;
      cerin:=-cerin;
      cerex:=-cerex;
    end;
// ckick , csept ?
  end;
  self.Init(cshandle);
end;

procedure TFormEdit.EditAxKeyPress(Sender: TObject; var Key: Char);
begin
  TEKeyVal(EditAx, Key, glob.ax, 5, 1);
end;

procedure TFormEdit.EditAyKeyPress(Sender: TObject; var Key: Char);
begin
  TEKeyVal(EditAy, Key, glob.ay, 5, 1);
end;

procedure TFormEdit.EdrrefKeyPress(Sender: TObject; var Key: char);
begin
  TEKeyVal(Edrref, Key, radref, 5, 1);
  DefSet('envel/rref',radref);
end;

procedure TFormEdit.ButAllAperClick(Sender: TObject);
var j:integer;
begin
  if ChkAllAper.Checked then begin
    for j:=1 to Glob.NElem do with Elem[j] do begin
      ax:=Glob.ax; ay:=Glob.ay;
    end;
  end else begin
    for j:=1 to Glob.NElem do with Elem[j] do begin
      if ax > Glob.ax then ax:=Glob.ax; if ay > Glob.ay then ay:=Glob.ay;
    end;
  end;
end;

procedure TFormEdit.ButExpUndClick(Sender: TObject);
// expand undulators -> create series of bends

begin
  ExpandUndulator;
  FillLists;
end;

end.
